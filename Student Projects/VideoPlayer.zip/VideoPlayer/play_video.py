import tkinter as tk
import cv2
from PIL import Image, ImageTk

# Create a basic video player class
class VideoPlayer:
    def __init__(self, root, video_source):
        self.root = root
        self.video_source = video_source

        # Initialize the video capture object
        self.cap = cv2.VideoCapture(video_source)
        
        # Create a canvas to display frames
        self.canvas = tk.Canvas(root, width=800, height=600)
        self.canvas.pack()

        # Start the video loop
        self.update()

    def update(self):
        # Read the next frame from the video
        ret, frame = self.cap.read()
        
        if ret:
            # Convert frame from BGR to RGB (Tkinter needs RGB format)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Convert the frame to an Image object
            img = Image.fromarray(frame)
            
            # Convert Image object to a PhotoImage object
            imgtk = ImageTk.PhotoImage(image=img)
            
            # Update the canvas with the new image
            self.canvas.create_image(0, 0, anchor=tk.NW, image=imgtk)
            
            # Keep a reference to the image object
            self.canvas.imgtk = imgtk
        
        # Continue updating at the next frame
        self.root.after(10, self.update)

# Create the Tkinter window
root = tk.Tk()
root.title("Simple Video Player")

# Define the video source (use the file path or a webcam index)
video_source = "your_video_file.mp4"  # You can replace this with a webcam index like 0

# Create an instance of the VideoPlayer class
player = VideoPlayer(root, video_source)

# Start the Tkinter event loop
root.mainloop()
