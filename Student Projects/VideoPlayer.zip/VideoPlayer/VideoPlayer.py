import cv2 
import tkinter   
from tkinter import *
from PIL import Image, ImageTk  

class VideoPlayer:  
    def __init__(self, master):  
        self.master = master  
        self.master.title('Video Player')
        
        self.video_source = None  
        self.cap = None  
        self.is_paused = False  
        self.current_frame = None  

        # Create a canvas for displaying video frames  
        self.canvas = tk.Canvas(master, width=640, height=480)  
        self.canvas.pack()  

        # Control buttons  
        self.play_button = tk.Button(master, text="Play", command=self.play_video)  
        self.play_button.pack(side=tk.LEFT)  

        self.pause_button = tk.Button(master, text="Pause", command=self.pause_video)  
        self.pause_button.pack(side=tk.LEFT)  

        self.stop_button = tk.Button(master, text="Stop", command=self.stop_video)  
        self.stop_button.pack(side=tk.LEFT)  

        self.browse_button = tk.Button(master, text="Browse", command=self.browse_video)  
        self.browse_button.pack(side=tk.LEFT)  

    def browse_video(self):  
        self.video_source = filedialog.askopenfilename(  
            initialdir="/", title="Select a Video File",  
            filetypes=(("MP4 files", "*.mp4"), ("All files", "*.*"))  
        )  
        if self.video_source:  
            self.cap = cv2.VideoCapture(self.video_source)  

    def play_video(self):  
        if self.cap is not None and not self.is_paused:  
            ret, frame = self.cap.read()  
            if ret:  
                self.current_frame = frame  
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  
                img = Image.fromarray(frame)  
                self.photo = ImageTk.PhotoImage(image=img)  
                self.canvas.create_image(0, 0, image=self.photo, anchor=tk.NW)  

            if not self.is_paused:  
                self.master.after(10, self.play_video)  

    def pause_video(self):  
        self.is_paused = not self.is_paused  

    def stop_video(self):  
        if self.cap:  
            self.cap.release()  
        self.canvas.delete("all")  
        self.is_paused = False  

    def on_closing(self):  
        if self.cap is not None:  
            self.cap.release()  
        self.master.destroy()  

if __name__ == "__main__":  
    root = tk.Tk()  
    player = VideoPlayer(root)  
    root.protocol("WM_DELETE_WINDOW", player.on_closing)  
    root.mainloop()